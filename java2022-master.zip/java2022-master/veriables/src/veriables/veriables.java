package veriables;

public class Veriables {

	public static void main(String[] args) {
		//'reusability' tekrar tekrar kullanılabilirlik
		int ogrenciSayisi=10;
		String  mesaj="Öğrenci Sayısı:";
		System.out.println(mesaj +ogrenciSayisi);
		System.out.println(mesaj +ogrenciSayisi);
		System.out.println(mesaj +ogrenciSayisi);
		System.out.println(mesaj +ogrenciSayisi);
		
		//Değişkenleri biz kod yazarken her sayfada tekrar tekrar değiştirmek yerine tek bir yerde değiştirme
		//kolaylığı sağlar. Örneğin öğrenci sayısını değişken olmadan da yazabiliyorken bu veriyi değiştirmek
		//istediğimizde tek tek kodlar üzerinde düzeltme yapmamız gerekecek buna gerek olmaması içinde
		// değişkenleri kullanıyoruz.
	}

}
