package javaHelloWorld;

public class JavaHelloWorld {

	public static void main(String[] args) {
		//intellisense
		
		System.out.println("Merhaba Java"); //Satırda yazı yazmamızı sağlar. System.out.println yazmamızın sebebi gruplama yapmamızı sağlıyor
		// Birçok fonksiyon olduğundan ezbere gerek olmadan kodun yazarken out altındaki fonksiyonu kullanmanın kolaylığını sağlar.
		

	}

}
