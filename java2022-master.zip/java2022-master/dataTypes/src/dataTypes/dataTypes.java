package dataTypes;

public class DataTypes {

	public static void main(String[] args) {
		//int : tam sayı tutar -2147483648 ve 2147483647 arası değer tutar 4 byte yer kaplar.
		//byte: tam sayı tutar -128 ile 127 arası değer tutar 1 byte yer kaplar.
		//short: tam sayı tutar -32768 ile 32767 arası değer tutar 2 byte yer kaplar.
		//long: tam sayı tutar -9223.... ile 9223.... arası değer tutar 8 byte yer kaplar.
		//double: ondalıklı sayı tutar. Genellikle kullanılır. 8 byte yer kaplar.
		//float: ondalıklı sayı tutar 4 byte yer kaplar.
		//char: tek karakter tutar tek tırnak içerisine yazılır. 2 byte yer kaplar.
		//boolean: true-false gibi veryi tutar. 1 byte yer kaplar.
		



	}

}
